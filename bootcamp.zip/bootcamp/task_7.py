# initializing list
number_list = [7, 8, 10, 12, 13, 15]s

# printing list
print ( "The original list : " + str ( number_list ) )

# Standard deviation of list
# Using sum() + list comprehension
mean = sum ( number_list ) / len ( number_list )
variance = sum ( [((x - mean) ** 2) for x in number_list] ) / len ( number_list )
res = variance ** 0.5

# Printing result
print ( "Standard deviation of sample is : " + str ( res ) )
