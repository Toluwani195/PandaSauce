# the string
line=input("Enter your word: ")
print(line)

# the replacing code
line= line.replace(" ","%20")

print(line)



